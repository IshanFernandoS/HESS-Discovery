Supplementary Data 1 - Elements and Pairs (TM-only)
Version: 1.2
Export date: 2026-07-17

Contents
- elements.csv: per-element descriptor inputs used by the multi-objective workflow.
- pairs.csv: metal-metal interaction proxies used for the MSI* descriptor.

Metadata status
The columns source_refs, provenance, mp_id and formula are reserved metadata fields but are not populated in this release. They are retained to preserve a stable schema for future source-level provenance. The descriptor values, sign conventions, aggregation rules and analysis usage are documented in the Supplementary Information and in this README.

Population audit
- elements.csv:source_refs: 0/16 populated
- pairs.csv:provenance: 0/64 populated
- pairs.csv:mp_id: 0/64 populated
- pairs.csv:formula: 0/64 populated

Notes
- elements.csv is filtered to transition metals only (IUPAC d-block: 3d, 4d, 5d).
- mu_uB is retained as a reserved/diagnostic field and is blank in this release.
- pairs.csv was built from the working metal-metal interaction dictionary used by the analysis; the sign_convention column records the MSI* convention.

SHA256 checksums
5b8aee030370a2eaec2199b0482dd016b4c14f0854575fbfa92bb4218002e88e  elements.csv
63a0b994c3c41b62cf7b9aa9237d2c990df0fa98713d820f232ff615fea5975e  pairs.csv

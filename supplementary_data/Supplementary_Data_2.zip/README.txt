Supplementary Data 2 — Descriptor Spreadsheet (Corrected)
Version: 1.1_CORRECTED
Export date: 2025-10-27

Checksums (SHA256)
-------------------
  Descriptors-2.xlsx: 2514dfde899aeef516044be3d53ab43a63706b93bf024f8cb559958d0e08ca71
  Descriptors-2.csv:  587077edb805c24f9913bc213ce4d3fa280709dd470709422176a45aa3fe7266

Changes in this corrected version
---------------------------------
- Added 'Element' column parsed from 'Binary Carbide' (e.g., TiC→Ti, Mo2C→Mo).
- Normalized headers to SI canonical names:
    * 'Formation Energy/ eV per atom' → 'Formation Energy / eV per atom'
    * 'Atomic Radius/ pm' → 'Atomic Radius / pm'
    * 'Electronegativity' → 'Electronegativity (Pauling)'
    * 'Carbide Melting Point' → 'Carbide Melting Point / K'

Required schema now satisfied:
  Binary Carbide, Element, Formation Energy / eV per atom,
  Carbide Melting Point / K, Atomic Radius / pm,
  Electronegativity (Pauling), Valence e Count

Note: Extra columns (e.g., 'MatProj ID', 'D0', 'Q', 'D(2300)', etc.) are preserved.

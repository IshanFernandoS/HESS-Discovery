Supplementary Data 3 - GNN input tensor and HEC5 feature/EFA-label table

Contents
- final_features_train.npy: frozen node-feature tensor used for the manuscript-consistent HEC5 GNN workflow.
- HEC5_output.xlsx and HEC5_output.csv: HEC5 feature and EFA-label table used for training and evaluation.
- Bond.csv and Bond.xlsx: Materials Project monocarbide bond/formation-energy source table used to append the Bond_Formation_Energy_per_atom node-feature channel, including source links where available.

Validation note
- final_features_train.npy has shape (545, 6, 35) and contains 545 NaN entries. The NaNs are confined to the carbon/auxiliary-node bond-formation-energy channel, where the metal-carbide bond feature is undefined by construction.
- No imputation or row deletion should be applied to this channel when reproducing the graph construction; downstream PyTorch Geometric graph assembly handles the bond feature according to the manuscript workflow.
- This archive does not contain a separate candidate-level prediction-output table. If such a table is cited, it should be added as an additional file or the manuscript wording should refer to the feature/EFA-label table instead.

SHA256 checksums
f65593f35a7d9c66f90007421e5ed7e881b4ced0d0bf0a6afc80366bb274b86b  Bond.csv
8f24d7ecba181b7ec748942e5731ef5c0f7e3d86ed564ec89311f770f8ac50d9  Bond.xlsx
9882714b97789e5278ae645cdd8f6c4ca04dcdadb2d9107a3714930bd1a12e7f  HEC5_output.csv
234bb5c775a135b5de75ed89d8d17b330e1957808a78408fe965e31358182504  HEC5_output.xlsx
d68d74560415192752fe139de3591261891b05e066fc8f40df40ec38ed8aabe1  final_features_train.npy
